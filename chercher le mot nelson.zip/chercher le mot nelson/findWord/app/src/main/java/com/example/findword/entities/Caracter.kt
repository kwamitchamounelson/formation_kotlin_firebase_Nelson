package com.example.findword.entities

data class Caracter(var char: Char,var x:Int,var y:Int) {
    constructor():this(' ',0,0)
}